#include <iostream>

int get_change(int n) {
  //write your code here
  return n;
}

int main() {
  int n;
  std::cin >> n;
  std::cout << get_change(n) << '\n';
}
