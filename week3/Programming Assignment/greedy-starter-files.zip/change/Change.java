import java.util.Scanner;

public class Change {
    private static int getChange(int n) {
        //write your code here
        return n;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        System.out.println(getChange(n));

    }
}

