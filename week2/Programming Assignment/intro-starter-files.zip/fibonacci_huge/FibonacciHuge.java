import java.util.*;

public class FibonacciHuge {
    private static long getFibonacciHuge(long n, long m) {
        //write your code here
        return 0;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        long n = scanner.nextLong();
        long m = scanner.nextLong();
        System.out.println(getFibonacciHuge(n, m));
    }
}

